"""
THE COMIC MACHINE  —  turn any photo into a PRINTED comic (not a painting)
by Peter + Claude, 2026.  Companion tool to paint_anything.py (THE PAINT MACHINE).

The paint machine repaints a photo with brush strokes.
This one pretends the photo was printed on a comic press: flat inked colours,
bold ink outlines, Ben-Day halftone dots for shading, newsprint paper, and
(in retro style) slightly misregistered printing plates.
"""
import os, math, random
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance

# ============================= CONFIG =============================
PHOTO  = "photo.jpg"          # <-- input image
OUT    = "comic.png"          # <-- output

STYLE  = "clean"   # "clean" | "retro" | "poster" | "manga"
#   clean  = modern comic: flat colours, sharp ink, light dots
#   retro  = old newsprint: paper tint, dots everywhere, colour plates slightly off
#   poster = few colours, heavy ink, no dots (screenprint / stall-sign look)
#   manga  = black & white, screentone dots, strong ink

COLORS   = 0       # 0 = use the style's default; else 3-16 flat colours
INK      = 1.0     # ink line thickness (0.6 thin ... 2.0 fat)
DETAIL   = 1.0     # how much fine linework survives (0.5 clean ... 1.6 busy)
HALFTONE = "auto"  # "auto" | "on" | "off"
CMYK     = "auto"  # "auto" | "on" | "off"  -- REAL 4-plate printing: cyan/magenta/yellow/black
                   #   screened at their classic angles (rosette pattern), each plate
                   #   printed slightly off-register like a real press
MISREG   = 0       # 0 = style default; plate offset in px (1 = tight press, 4 = sloppy)
DOT      = 0       # 0 = style default; else halftone dot pitch in px (4 fine ... 12 chunky)
SAT      = 0       # 0 = style default; else colour punch (1.0 natural ... 1.6 loud)
PANEL    = True    # comic panel frame
W        = 1400    # output width in px
SEED     = 7
# ==================================================================

STYLE_DEFAULTS = {
    "clean":  dict(colors=10, dot=7,  sat=1.30, paper=(255, 252, 246), dots_strength=0.55, cmyk=False, misreg=0),
    "retro":  dict(colors=7,  dot=6,  sat=1.15, paper=(247, 236, 208), dots_strength=0.85, cmyk=False, misreg=2),
    "press":  dict(colors=8,  dot=6,  sat=1.20, paper=(250, 243, 226), dots_strength=0.0,  cmyk=True,  misreg=2),
    "poster": dict(colors=5,  dot=8,  sat=1.45, paper=(253, 248, 238), dots_strength=0.0,  cmyk=False, misreg=0),
    "manga":  dict(colors=4,  dot=5,  sat=0.0,  paper=(252, 250, 245), dots_strength=1.0,  cmyk=False, misreg=0),
}
# the four printing plates: (name, screen angle, ink colour as RGB)
PLATES = [("C", 15.0, (0, 158, 224)), ("M", 75.0, (226, 0, 122)),
          ("Y",  0.0, (255, 232, 0)), ("K", 45.0, (32, 26, 24))]
INK_COLOR = (28, 22, 20)

def load(path, width):
    im = Image.open(path)
    if im.mode in ("RGBA", "LA", "P"):
        im = im.convert("RGBA")
        bg = Image.new("RGBA", im.size, (255, 255, 255, 255))
        im = Image.alpha_composite(bg, im)
    im = im.convert("RGB")
    h = round(im.height * width / im.width)
    return im.resize((width, h), Image.LANCZOS)

def flatten_colors(bgr, k, seed):
    """k-means in Lab space -> flat comic colours."""
    lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB)
    Z = lab.reshape((-1, 3)).astype(np.float32)
    crit = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 24, 1.0)
    cv2.setRNGSeed(seed)
    _, labels, centers = cv2.kmeans(Z, k, None, crit, 3, cv2.KMEANS_PP_CENTERS)
    quant = centers[labels.flatten()].reshape(lab.shape).astype(np.uint8)
    return cv2.cvtColor(quant, cv2.COLOR_LAB2BGR)

def ink_mask(bgr_smooth, ink, detail):
    """Crisp printed outlines: strong edges + a little interior linework, despeckled."""
    gray = cv2.cvtColor(bgr_smooth, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (0, 0), 1.1)
    med = float(np.median(blur))
    lo = int(max(10, 0.62 * med / max(detail, .3)))
    hi = int(min(255, 1.55 * med / max(detail, .3)))
    edges = cv2.Canny(blur, lo, hi)
    if detail > 0.9:                                  # extra interior lines
        adap = cv2.adaptiveThreshold(cv2.medianBlur(gray, 5), 255,
                                     cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV,
                                     blockSize=9, C=max(2, int(9 - 4 * detail)))
        adap = cv2.morphologyEx(adap, cv2.MORPH_OPEN, np.ones((2, 2), np.uint8))
        edges = cv2.bitwise_or(edges, adap)
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, np.ones((2, 2), np.uint8))
    # despeckle: drop tiny blobs (print noise)
    n, lab_, stats, _ = cv2.connectedComponentsWithStats(edges, 8)
    keep = np.zeros_like(edges)
    min_area = max(6, int(14 / max(detail, .4)))
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            keep[lab_ == i] = 255
    t = max(1, int(round(1 + 1.6 * (ink - 1))) if ink >= 1 else 1)
    if ink >= 1.35: keep = cv2.dilate(keep, np.ones((t + 1, t + 1), np.uint8))
    elif ink >= 1.0: keep = cv2.dilate(keep, np.ones((2, 2), np.uint8))
    return keep

def halftone(shade, pitch, strength, size, seed):
    """Ben-Day dots at 45 degrees; dot size grows where the picture is darker."""
    w, h = size
    layer = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(layer)
    ang = math.radians(45)
    ca, sa = math.cos(ang), math.sin(ang)
    diag = int(math.hypot(w, h) / pitch) + 2
    rnd = random.Random(seed)
    for j in range(-diag, diag):
        for i in range(-diag, diag):
            x = (i * ca - j * sa) * pitch + w / 2
            y = (i * sa + j * ca) * pitch + h / 2
            if not (0 <= x < w and 0 <= y < h):
                continue
            v = shade[int(y), int(x)] / 255.0          # 0 = light, 1 = dark
            if v <= 0.03:
                continue
            r = pitch * 0.62 * math.sqrt(min(v, 1.0)) * strength
            if r < 0.35:
                continue
            jx, jy = rnd.uniform(-.25, .25), rnd.uniform(-.25, .25)
            d.ellipse([x - r + jx, y - r + jy, x + r + jx, y + r + jy], fill=255)
    return layer

def screen(density, pitch, angle_deg):
    """One printing plate's halftone screen: dots on a grid rotated to the plate's angle,
    dot AREA proportional to ink density. Vectorised, so it is fast and razor sharp."""
    h, w = density.shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    a = math.radians(angle_deg)
    u = xx * math.cos(a) + yy * math.sin(a)
    v = -xx * math.sin(a) + yy * math.cos(a)
    fu = (u / pitch) % 1.0 - 0.5
    fv = (v / pitch) % 1.0 - 0.5
    dist = np.sqrt(fu * fu + fv * fv)                 # distance from cell centre (cell units)
    r = 0.56 * np.sqrt(np.clip(density, 0, 1))        # radius: area grows with ink
    return np.clip((r - dist) * pitch * 1.5 + 0.5, 0, 1).astype(np.float32)   # soft edge

def cmyk_press(rgb, pitch, misreg, paper, seed):
    """Separate into C/M/Y/K plates, screen each at its own angle, print them one by one
    slightly off-register onto the paper. This is what makes a real rosette pattern."""
    a = rgb.astype(np.float32) / 255.0
    k = 1.0 - a.max(axis=2)
    den = np.clip(1.0 - k, 1e-6, None)
    c = (1.0 - a[..., 0] - k) / den
    m = (1.0 - a[..., 1] - k) / den
    y = (1.0 - a[..., 2] - k) / den
    dens = {"C": np.clip(c, 0, 1), "M": np.clip(m, 0, 1), "Y": np.clip(y, 0, 1), "K": np.clip(k, 0, 1)}
    rnd = random.Random(seed)
    sheet = np.ones_like(a) * (np.array(paper, np.float32) / 255.0)
    for name, angle, ink in PLATES:
        cov = screen(dens[name], pitch, angle)
        if misreg:                                     # this plate landed a bit off
            dx = rnd.randint(-misreg, misreg)
            dy = rnd.randint(-misreg, misreg)
            if name == "K":                            # black usually registers best
                dx, dy = dx // 2, dy // 2
            cov = np.roll(np.roll(cov, dy, axis=0), dx, axis=1)
        ink_rgb = np.array(ink, np.float32) / 255.0
        cov3 = cov[..., None]
        sheet = sheet * ((1.0 - cov3) + cov3 * ink_rgb)   # transparent process ink: multiply
    return np.clip(sheet * 255.0, 0, 255).astype(np.uint8), sum(float((screen(dens[n], pitch, ang) > .5).mean()) for n, ang, _ in PLATES)

def paper_texture(size, base, seed):
    w, h = size
    rnd = np.random.default_rng(seed)
    grain = rnd.normal(0, 4.2, (h, w, 1))
    fib = rnd.normal(0, 9.0, (h // 3 + 1, w // 3 + 1, 1))
    fib = np.array(Image.fromarray(np.clip(fib[..., 0] + 128, 0, 255).astype(np.uint8))
                   .resize((w, h), Image.BILINEAR), dtype=float)[..., None] - 128
    sheet = np.array(base, dtype=float)[None, None, :] + grain + fib * 0.35
    return np.clip(sheet, 0, 255).astype(np.uint8)

def main():
    cfg = STYLE_DEFAULTS[STYLE]
    colors = COLORS or cfg["colors"]
    dot    = DOT or cfg["dot"]
    sat    = SAT or cfg["sat"]
    random.seed(SEED); np.random.seed(SEED)

    im = load(PHOTO, W)
    w, h = im.size
    if sat and STYLE != "manga":
        im = ImageEnhance.Color(im).enhance(sat)
    bgr = cv2.cvtColor(np.array(im), cv2.COLOR_RGB2BGR)

    # 1. flatten the light: bilateral keeps edges razor sharp while killing gradients
    sm = bgr
    for _ in range(3):
        sm = cv2.bilateralFilter(sm, 9, 90, 90)

    # 2. flat printed colours
    if STYLE == "manga":
        g = cv2.cvtColor(sm, cv2.COLOR_BGR2GRAY)
        lv = np.linspace(0, 255, colors)
        idx = np.clip((g.astype(float) / 255 * (colors - 1)).round().astype(int), 0, colors - 1)
        flat = cv2.cvtColor(lv[idx].astype(np.uint8), cv2.COLOR_GRAY2BGR)
    else:
        flat = flatten_colors(sm, colors, SEED)

    # 3. ink
    ink = ink_mask(sm, INK, DETAIL)
    ink_px = int((ink > 0).sum())

    # 4. halftone dots in the shaded areas
    use_cmyk = CMYK == "on" or (CMYK == "auto" and cfg["cmyk"])
    dots_on = (not use_cmyk) and (HALFTONE == "on" or (HALFTONE == "auto" and cfg["dots_strength"] > 0))
    dot_px = 0
    rgb = cv2.cvtColor(flat, cv2.COLOR_BGR2RGB)
    out = Image.fromarray(rgb)
    misreg = MISREG if MISREG else cfg["misreg"]
    plate_cov = 0.0
    if use_cmyk:
        pressed, plate_cov = cmyk_press(np.array(out), dot, misreg, cfg["paper"], SEED)
        out = Image.fromarray(pressed)
    elif dots_on and cfg["dots_strength"] > 0:
        lum = cv2.cvtColor(flat, cv2.COLOR_BGR2GRAY).astype(float)
        shade = np.clip((205 - lum) / 205 * 255, 0, 255)          # darker -> bigger dots
        shade[lum < 45] = 0                                        # pure blacks stay solid
        shade = cv2.GaussianBlur(shade, (0, 0), 1.2).astype(np.uint8)
        layer = halftone(shade, dot, cfg["dots_strength"], (w, h), SEED)
        dot_px = int((np.array(layer) > 0).sum())
        shadow = Image.fromarray(np.clip(np.array(out, float) * 0.78, 0, 255).astype(np.uint8))
        out = Image.composite(shadow, out, layer.point(lambda v: int(v * 0.9)))

    # 5. misregistered printing plates (retro)
    if misreg and not use_cmyk:
        a = np.array(out)
        m = misreg
        a[..., 0] = np.roll(a[..., 0], m, axis=1)
        a[..., 2] = np.roll(a[..., 2], -m, axis=0)
        out = Image.fromarray(a)

    # 6. paper, then ink on top (ink never gets printed under the paper)
    sheet = Image.fromarray(paper_texture((w, h), cfg["paper"], SEED))
    blend = 1.0 if not use_cmyk else 0.45      # plates already sit on paper; just add texture
    tex = 1.0 - blend * (1.0 - np.array(sheet, float) / 255)
    out = Image.fromarray(np.clip(np.array(out, float) * tex, 0, 255).astype(np.uint8))
    ink_img = Image.new("RGB", (w, h), INK_COLOR)
    ink_soft = Image.fromarray(ink).filter(ImageFilter.GaussianBlur(0.4))
    out = Image.composite(ink_img, out, ink_soft)

    # 7. panel frame
    if PANEL:
        pad = max(10, w // 90)
        framed = Image.new("RGB", (w + pad * 4, h + pad * 4), cfg["paper"])
        framed.paste(out, (pad * 2, pad * 2))
        d = ImageDraw.Draw(framed)
        d.rectangle([pad, pad, w + pad * 3, h + pad * 3], outline=INK_COLOR, width=max(3, pad // 2))
        out = framed

    out.save(OUT)
    print(f"comicified: style={STYLE}, {colors} colours, screen pitch={dot if (dots_on or use_cmyk) else '-'}")
    if use_cmyk:
        print(f"  CMYK press: 4 plates at 15/75/0/45 deg, misregistration +-{misreg}px, ink coverage {plate_cov*100:.0f}%")
    print(f"  ink pixels: {ink_px:,}   halftone dot pixels: {dot_px:,}")
    print(f"  -> {OUT}")

if __name__ == "__main__":
    main()
