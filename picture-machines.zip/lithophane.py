"""
THE LITHOPHANE MACHINE — turn a photo into a 3D-printable STL that only shows the
picture when you hold it up to a light.  By Peter + Claude, 2026.

Dark parts of the photo become THICK plastic (little light gets through), bright parts
become THIN.  Printed standing up in white filament it looks like a blank plate until
you backlight it.
"""
import os, math, struct
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter, ImageOps

# ============================= CONFIG =============================
PHOTO   = "photo.jpg"
OUT     = "lithophane.stl"
PREVIEW = "lithophane-preview.png"     # simulated backlit look ("" = skip)

# ---- size (millimetres) ----
WIDTH_MM   = 100.0     # width of the picture area
HEIGHT_MM  = 0         # 0 = keep the photo's aspect ratio
MIN_MM     = 0.7       # thinnest (brightest) spots  - 0.6-0.8 works on most printers
MAX_MM     = 3.0       # thickest (darkest) spots    - 2.5-3.5; more = higher contrast
ADAPTIVE   = True      # variable triangles: big flat areas (sky, background) get merged into
                       # few large triangles, detailed areas keep every sample. Same picture,
                       # far smaller file. False = plain grid, one quad per sample.
TOL_MM     = 0.04      # how far the mesh may deviate from the true surface when merging.
                       # 0.02 = fussy (more triangles), 0.08 = aggressive (fewer)
MAX_BLOCK  = 16        # biggest merge, in samples (must be a power of two)
VERIFY     = True      # after writing, check the mesh is watertight (every edge used twice)

RES        = 4.5       # samples per mm. 4.5 = 0.22 mm per sample, which is already finer
                       # than a 0.4 mm nozzle can print. Higher only makes the file bigger.

# ---- shape ----
SHAPE      = "rounded" # "rect" | "rounded" | "circle" | "arch" | "hex" | "hex-flat"
                       #   hex      = pointy top (the 3D logo shape)
                       #   hex-flat = flat top
CORNER_MM  = 4.0       # corner radius for "rounded"
FRAME_MM   = 0         # 0 = none; else a solid border this wide, following the plate's
                       # shape (hexagon, circle, rounded rect... and around the hanging hole)
FRAME_THICK_MM = 0     # 0 = frame is MAX_MM thick (flush). Set higher (e.g. 4.5) for a
                       # RAISED rim: looks like a picture frame and stiffens the print
FRAME_STEP = True      # True = crisp step between frame and picture; False = soft blend
CURVE_R    = 0         # 0 = flat panel; else bend it around a cylinder of this radius mm
                       #   (curved lithophanes warp less and look great around a lamp)
HANG_MM    = 0         # 0 = none; else diameter of a hanging hole near the top (ornaments)

# ---- picture treatment ----
INVERT     = False     # True = negative (for backlit signs where you want dark background)
GAMMA      = 1.0       # <1 brightens midtones, >1 darkens them (1.2-1.6 adds punch)
CONTRAST   = 1.15      # 1.0 off
SHARPEN    = 1.0       # 0 off, 1 normal, 2 crisp (small details survive the plastic better)
FLIP       = False     # mirror left-right (only needed if you print it face-down)
# ==================================================================

def load_height_image(path, nx, ny):
    im = Image.open(path)
    if im.mode in ("RGBA", "LA", "P"):
        im = im.convert("RGBA")
        im = Image.alpha_composite(Image.new("RGBA", im.size, (255, 255, 255, 255)), im)
    im = im.convert("L").resize((nx, ny), Image.LANCZOS)
    if SHARPEN > 0:
        im = im.filter(ImageFilter.UnsharpMask(radius=1.6, percent=int(90 * SHARPEN), threshold=2))
    if CONTRAST != 1.0:
        im = ImageEnhance.Contrast(im).enhance(CONTRAST)
    a = np.asarray(im, dtype=np.float32) / 255.0
    if GAMMA != 1.0:
        a = np.power(a, GAMMA)
    if INVERT:
        a = 1.0 - a
    if FLIP:
        a = a[:, ::-1]
    return a                      # 1.0 = bright = thin

def build_mask(nx, ny, w_mm, h_mm, res):
    """Which grid cells are part of the plate (lets us do rounded corners, circles, holes)."""
    yy, xx = np.mgrid[0:ny, 0:nx].astype(np.float32)
    X = xx / max(nx - 1, 1) * w_mm
    Y = yy / max(ny - 1, 1) * h_mm
    m = np.ones((ny, nx), bool)
    if SHAPE == "rounded" and CORNER_MM > 0:
        r = CORNER_MM
        for cx, cy in [(r, r), (w_mm - r, r), (r, h_mm - r), (w_mm - r, h_mm - r)]:
            near = ((np.abs(X - cx) > r) | (np.abs(Y - cy) > r))
            corner = ((X < r) if cx < w_mm / 2 else (X > w_mm - r)) & \
                     ((Y < r) if cy < h_mm / 2 else (Y > h_mm - r))
            m &= ~(corner & (np.hypot(X - cx, Y - cy) > r) & near)
    elif SHAPE in ("hex", "hex-flat"):
        flat_top = SHAPE == "hex-flat"
        cx, cy = w_mm / 2, h_mm / 2
        R = min(h_mm / 2, w_mm / math.sqrt(3)) if not flat_top else min(w_mm / 2, h_mm / math.sqrt(3))
        apo = R * math.sqrt(3) / 2
        for deg in ([90, 30, 150] if flat_top else [0, 60, 120]):
            th = math.radians(deg)
            m &= np.abs((X - cx) * math.cos(th) + (Y - cy) * math.sin(th)) <= apo
    elif SHAPE == "circle":
        cx, cy, r = w_mm / 2, h_mm / 2, min(w_mm, h_mm) / 2
        m &= np.hypot(X - cx, Y - cy) <= r
    elif SHAPE == "arch":
        r = w_mm / 2
        m &= ~((Y < r) & (np.hypot(X - w_mm / 2, Y - r) > r))
    if HANG_MM > 0:
        hr = HANG_MM / 2
        hy = max(hr + 2.0, h_mm * 0.045 + hr)
        m &= np.hypot(X - w_mm / 2, Y - hy) > hr
    return m

def node_xyz(i, j, t, nx, ny, w_mm, h_mm):
    """One mesh vertex. X = across, Z = up (so it prints standing), Y = thickness."""
    x = i / max(nx - 1, 1) * w_mm
    z = (1 - j / max(ny - 1, 1)) * h_mm
    if CURVE_R > 0:
        th = (x - w_mm / 2) / CURVE_R
        return ((CURVE_R + t) * math.sin(th), (CURVE_R + t) * math.cos(th) - CURVE_R, z)
    return (x, t, z)

def main():
    w_mm = float(WIDTH_MM)
    probe = Image.open(PHOTO)
    h_mm = float(HEIGHT_MM) if HEIGHT_MM else w_mm * probe.height / probe.width
    nx = max(8, int(round(w_mm * RES)) + 1)
    ny = max(8, int(round(h_mm * RES)) + 1)

    bright = load_height_image(PHOTO, nx, ny)
    thick = MIN_MM + (1.0 - bright) * (MAX_MM - MIN_MM)
    mask = build_mask(nx, ny, w_mm, h_mm, RES)
    if FRAME_MM > 0:                                   # border that follows the plate's shape
        k = max(1.0, FRAME_MM * RES)
        try:                                           # distance to the nearest outside pixel
            from scipy import ndimage
            dist = ndimage.distance_transform_edt(mask)
        except Exception:                              # no scipy: erode with a square kernel
            from PIL import ImageFilter as _IF
            size = int(2 * round(k) + 1)
            er = Image.fromarray((mask * 255).astype(np.uint8)).filter(_IF.MinFilter(size))
            dist = np.where(np.asarray(er) > 127, k + 1.0, 0.0)
        ft = FRAME_THICK_MM if FRAME_THICK_MM > 0 else MAX_MM
        band = mask & (dist <= k)
        if FRAME_STEP:
            thick = np.where(band, ft, thick)
        else:                                          # blend the inner 40% of the band
            t = np.clip((k - dist) / max(k * 0.4, 1e-6), 0, 1)
            thick = np.where(band, thick * (1 - t) + ft * t, thick)

    tris = []
    def quad(a, b, c, d):                              # two triangles, consistent winding
        tris.append((a, b, c)); tris.append((a, c, d))

    cell = mask[:-1, :-1] & mask[:-1, 1:] & mask[1:, :-1] & mask[1:, 1:]
    ncx, ncy = nx - 1, ny - 1
    N = lambda i, j, t: node_xyz(i, j, t, nx, ny, w_mm, h_mm)
    T = lambda i, j: float(thick[j, i])

    # ---- variable triangles: quadtree over the height field -------------------
    lvl = np.ones((ncy, ncx), np.int32)                # size of the leaf covering each cell
    leaves = []
    def flat_enough(i0, j0, sz):
        sub = thick[j0:j0 + sz + 1, i0:i0 + sz + 1]
        u = np.linspace(0, 1, sz + 1)[None, :]
        v = np.linspace(0, 1, sz + 1)[:, None]
        approx = (sub[0, 0] * (1 - u) * (1 - v) + sub[0, -1] * u * (1 - v)
                  + sub[-1, 0] * (1 - u) * v + sub[-1, -1] * u * v)
        return float(np.abs(sub - approx).max()) <= TOL_MM
    def ring_ok(i0, j0, sz):                           # keep a 1-cell frame at full detail so
        a, b = j0 - 1, j0 + sz + 1                     # the side walls always stitch exactly
        c, d = i0 - 1, i0 + sz + 1
        if a < 0 or c < 0 or b > ncy or d > ncx:
            return False
        return bool(cell[a:b, c:d].all())
    def rec(i0, j0, sz):
        if sz == 1:
            if i0 < ncx and j0 < ncy and cell[j0, i0]:
                leaves.append((i0, j0, 1))
            return
        if (i0 + sz <= ncx and j0 + sz <= ncy and ring_ok(i0, j0, sz) and flat_enough(i0, j0, sz)):
            leaves.append((i0, j0, sz)); lvl[j0:j0 + sz, i0:i0 + sz] = sz; return
        h = sz // 2
        for dj in (0, h):
            for di in (0, h):
                rec(i0 + di, j0 + dj, h)
    if ADAPTIVE:
        for j0 in range(0, ncy, MAX_BLOCK):
            for i0 in range(0, ncx, MAX_BLOCK):
                rec(i0, j0, MAX_BLOCK)
        # balance: no leaf may touch a neighbour more than twice as small (avoids cracks)
        changed = True
        while changed:
            changed, nxt = False, []
            for (i0, j0, sz) in leaves:
                if sz == 1:
                    nxt.append((i0, j0, sz)); continue
                fine = False
                for a, b, c, d in ((j0 - 1, j0, i0, i0 + sz), (j0 + sz, j0 + sz + 1, i0, i0 + sz),
                                   (j0, j0 + sz, i0 - 1, i0), (j0, j0 + sz, i0 + sz, i0 + sz + 1)):
                    if a < 0 or c < 0 or b > ncy or d > ncx:
                        continue
                    strip, act = lvl[a:b, c:d], cell[a:b, c:d]
                    if act.any() and int(strip[act].min()) * 2 < sz:
                        fine = True; break
                if fine:
                    h = sz // 2
                    for dj in (0, h):
                        for di in (0, h):
                            nxt.append((i0 + di, j0 + dj, h))
                            lvl[j0 + dj:j0 + dj + h, i0 + di:i0 + di + h] = h
                    changed = True
                else:
                    nxt.append((i0, j0, sz))
            leaves = nxt
        big = [L for L in leaves if L[2] > 1]
        for (i0, j0, sz) in big:                       # fan a merged block, with edge midpoints
            h = sz // 2
            pts = [(i0, j0)]
            def edge_finer(a, b, c, d):
                if a < 0 or c < 0 or b > ncy or d > ncx: return False
                strip, act = lvl[a:b, c:d], cell[a:b, c:d]
                return bool(act.any() and int(strip[act].min()) < sz)
            if edge_finer(j0 - 1, j0, i0, i0 + sz): pts.append((i0 + h, j0))
            pts.append((i0 + sz, j0))
            if edge_finer(j0, j0 + sz, i0 + sz, i0 + sz + 1): pts.append((i0 + sz, j0 + h))
            pts.append((i0 + sz, j0 + sz))
            if edge_finer(j0 + sz, j0 + sz + 1, i0, i0 + sz): pts.append((i0 + h, j0 + sz))
            pts.append((i0, j0 + sz))
            if edge_finer(j0, j0 + sz, i0 - 1, i0): pts.append((i0, j0 + h))
            ctr = N(i0 + h, j0 + h, T(i0 + h, j0 + h))
            ctr_b = N(i0 + h, j0 + h, 0)
            for k in range(len(pts)):
                a_i, a_j = pts[k]; b_i, b_j = pts[(k + 1) % len(pts)]
                tris.append((ctr, N(a_i, a_j, T(a_i, a_j)), N(b_i, b_j, T(b_i, b_j))))
                # the back gets the SAME fan (same boundary points, flat) so front and back
                # share identical edges -- that is what keeps the solid watertight
                tris.append((ctr_b, N(b_i, b_j, 0), N(a_i, a_j, 0)))
        merged = np.zeros((ncy, ncx), bool)
        for (i0, j0, sz) in big:
            merged[j0:j0 + sz, i0:i0 + sz] = True
    else:
        merged = np.zeros((ncy, ncx), bool)
    front_full = 2 * int(cell.sum())
    # ---------------------------------------------------------------------------

    for j in range(ny - 1):
        for i in range(nx - 1):
            if not cell[j, i] or merged[j, i]:
                continue
            t00, t10 = float(thick[j, i]), float(thick[j, i + 1])
            t11, t01 = float(thick[j + 1, i + 1]), float(thick[j + 1, i])
            f00, f10, f11, f01 = N(i, j, t00), N(i + 1, j, t10), N(i + 1, j + 1, t11), N(i, j + 1, t01)
            b00, b10, b11, b01 = N(i, j, 0), N(i + 1, j, 0), N(i + 1, j + 1, 0), N(i, j + 1, 0)
            quad(f00, f10, f11, f01)                   # front (the picture)
            quad(b00, b01, b11, b10)                   # back
            if i == 0 or not cell[j, i - 1]:   quad(f00, f01, b01, b00)
            if i == nx - 2 or not cell[j, i + 1]: quad(f11, f10, b10, b11)
            if j == 0 or not cell[j - 1, i]:   quad(f10, f00, b00, b10)
            if j == ny - 2 or not cell[j + 1, i]: quad(f01, f11, b11, b01)

    with open(OUT, "wb") as fh:
        fh.write(b"lithophane by Peter + Claude".ljust(80, b"\0"))
        fh.write(struct.pack("<I", len(tris)))
        for a, b, c in tris:
            u = np.subtract(b, a); v = np.subtract(c, a)
            n = np.cross(u, v); ln = np.linalg.norm(n)
            n = n / ln if ln > 1e-12 else np.array([0.0, 0.0, 1.0])
            fh.write(struct.pack("<3f", *n))
            for p in (a, b, c):
                fh.write(struct.pack("<3f", *p))
            fh.write(struct.pack("<H", 0))

    if VERIFY:
        import collections
        edges = collections.Counter()
        Q = lambda v: (round(float(v[0]), 4), round(float(v[1]), 4), round(float(v[2]), 4))
        for a, b, c in tris:
            qa, qb, qc = Q(a), Q(b), Q(c)
            for e in ((qa, qb), (qb, qc), (qc, qa)):
                edges[tuple(sorted(e))] += 1
        bad = sum(1 for v in edges.values() if v != 2)
        print(f"  mesh check: {'WATERTIGHT' if bad == 0 else str(bad) + ' NON-MANIFOLD EDGES (do not print)'}")

    if PREVIEW:
        mu = 1.35 / max(MAX_MM - MIN_MM, .01)          # simulated light through the plastic
        lit = np.exp(-mu * (thick - MIN_MM))
        lit = (lit - lit.min()) / max(lit.max() - lit.min(), 1e-6)
        img = (lit * 255).astype(np.uint8)
        rgb = np.dstack([img, (img * 0.985).astype(np.uint8), (img * 0.93).astype(np.uint8)])
        rgb[~mask] = (18, 18, 22)
        Image.fromarray(rgb).resize((min(1200, nx * 2), int(min(1200, nx * 2) * ny / nx)),
                                    Image.LANCZOS).save(PREVIEW)

    mb = os.path.getsize(OUT) / 1048576
    print(f"lithophane: {w_mm:.0f} x {h_mm:.0f} mm, {MIN_MM}-{MAX_MM} mm thick, shape={SHAPE}"
          + (f", curved R{CURVE_R:.0f}" if CURVE_R else "") + (f", hang hole {HANG_MM}mm" if HANG_MM else ""))
    if ADAPTIVE:
        print(f"  grid {nx} x {ny} at {RES}/mm -> {len(tris):,} triangles, {mb:.1f} MB"
              f"   (variable triangles: {len([L for L in leaves if L[2] > 1]):,} flat areas merged"
              f" within {TOL_MM} mm)")
    else:
        print(f"  grid {nx} x {ny} at {RES}/mm -> {len(tris):,} triangles, {mb:.1f} MB")
    print(f"  -> {OUT}" + (f"   preview: {PREVIEW}" if PREVIEW else ""))
    print("  PRINT: standing up (as oriented), white filament, 0.1 mm layers,")
    print("         no supports, and enough walls/infill that it is SOLID (100% infill is simplest).")

if __name__ == "__main__":
    main()
