# PICTURE MACHINES — by Peter + Claude, 2026

Four tools. One photo in, art (or a printable object) out.

| Tool | What it does | Guide |
|---|---|---|
| `photo_machine.py` | **the launcher** — runs any/all of the machines with presets | this file |
| `paint_anything.py` | **paints** the photo with real brush strokes | PAINT-MACHINE-GUIDE.md |
| `comicify.py` | **prints** it as a comic — flat ink, halftone, real CMYK press | COMIC-MACHINE-GUIDE.md |
| `lithophane.py` | **3D-prints** it — an STL that shows the picture when backlit | LITHOPHANE-MACHINE-GUIDE.md |

## Quick start

```bash
python3 photo_machine.py cat.jpg --all                 # one of each
python3 photo_machine.py cat.jpg --comic press         # CMYK comic print
python3 photo_machine.py logo.png --litho hex          # hexagon lithophane (the 3D logo shape)
python3 photo_machine.py cat.jpg --litho card --set WIDTH_MM=140 MAX_MM=3.4
```

Every machine also runs on its own — open it and edit the CONFIG block at the top.

Needs: Python 3 with **numpy, Pillow**, plus **opencv-python** (comic) and **scipy** (paint worlds).

Each tool prints honest numbers when it finishes: stroke counts, ink pixels, plate coverage,
triangle counts. Those are real, counted, not estimated.

Examples in this folder: Snippet (Silly Old Restaurant's mascot) in all five comic styles,
and as a hexagon lithophane with its backlit preview.
