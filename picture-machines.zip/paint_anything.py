"""
PAINT ANYTHING — brush-stroke painting machine
==============================================
Turns any photo into a painting made of real brush strokes, with optional
invented backgrounds (cut the subject out, place it in a new world).

Made by Peter + Claude, Berlin, 2026.

HOW TO USE (for a Claude chat):
1. Put the photo path in PHOTO below.
2. Pick MODE and WORLD in the CONFIG block.
3. Run:  python3 paint_anything.py
4. Result lands in /mnt/user-data/outputs/ — view it, then present it.

Dependencies: pillow + numpy (usually preinstalled).
scipy is only needed if WORLD != "none":  pip install scipy --break-system-packages
"""

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
import random

# ============================= CONFIG =============================
PHOTO = "/mnt/user-data/uploads/70333.webp"   # <-- change to the uploaded photo
OUT   = "/mnt/user-data/outputs/painted.png"

MODE  = "ultrafine"   # "chunky" | "normal" | "fine" | "ultrafine" | "marker"
WORLD = "none"        # "none" | "cloud" | "meadow"   (none = keep the photo's own background)

# WORLD cutout only works when the subject is clearly DARKER than the background
# (e.g. a black cat on a light bed). Raise/lower if the mask grabs too little/much.
CUTOUT_DARKNESS = 78          # pixels darker than this are "the subject"

# "realistic brushes" -> True (tapered pressure strokes, bristles, impasto light/shadow,
#                        dry-brush ends, canvas weave). False = the old simple flat strokes.
REALISTIC_BRUSHES = True

# MARKER mode dials — Peter can ask for these in words:
# "saturation down"  -> lower MARKER_SAT  (1.45 = punchy comic, 1.0 = natural, 0.6 = faded/vintage)
# "fewer colors"     -> lower MARKER_COLORS (12 = normal comic, 8 = simpler, 5 = poster, 3 = extreme)
# "pure color"       -> MARKER_STREAKS = False (flat cel-shaded fills, no visible marker lines)
# "streaky marker"   -> MARKER_STREAKS = True  (visible marker sweep texture)
MARKER_STREAKS = False
# "more vibrant"     -> raise MARKER_VIBRANCE (boosts the SHY colors most; 1.0 off, 1.5 punchy, 2.0 max pop)
# "more saturated"   -> raise MARKER_SAT (boosts ALL colors equally)
MARKER_VIBRANCE = 1.5
MARKER_SAT    = 1.45
MARKER_COLORS = 12

SEED = 1107                   # change for different strokes on the same photo
# ==================================================================

# canvas width per mode (bigger = finer detail, slower)
MODE_W      = {"chunky": 1100, "normal": 1200, "fine": 1400, "ultrafine": 1600, "marker": 1300}
# brush layers per mode: (radius, error_threshold). -1 = paint everywhere.
MODE_LAYERS = {
    "chunky":    [(30, -1), (16, 60), (9, 70)],
    "normal":    [(24, -1), (13, 55), (7, 55), (4, 62), (2, 80)],
    "fine":      [(24, -1), (13, 50), (7, 50), (4, 58), (2, 68), (1, 82)],
    "ultrafine": [(26, -1), (14, 50), (8, 50), (4, 55), (2, 60), (1, 72)],
}

random.seed(SEED)
np.random.seed(SEED)

# ---------------- load photo ----------------
W = MODE_W[MODE]
img = Image.open(PHOTO).convert("RGB")
w0, h0 = img.size
H = round(h0 * W / w0)
photo = img.resize((W, H), Image.LANCZOS)
pa = np.asarray(photo, dtype=np.float32)


# ---------------- optional: cut out a dark subject ----------------
def dark_subject_mask():
    from scipy import ndimage
    lum = 0.3 * pa[:, :, 0] + 0.59 * pa[:, :, 1] + 0.11 * pa[:, :, 2]
    m = lum < CUTOUT_DARKNESS
    m = ndimage.binary_opening(m, iterations=2)
    lbl, n = ndimage.label(m)
    if n > 1:
        sizes = ndimage.sum(m, lbl, range(1, n + 1))
        m = lbl == (np.argmax(sizes) + 1)       # keep the biggest blob
    m = ndimage.binary_fill_holes(m)
    m = ndimage.binary_dilation(m, iterations=2)
    soft = np.asarray(
        Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(2.5)),
        dtype=np.float32) / 255.0
    return m, soft[:, :, None]


def vgrad(d, x0, y0, x1, y1, c_top, c_bot):
    hgt = y1 - y0
    for i in range(hgt):
        p = i / max(1, hgt - 1)
        c = tuple(int(a + (b - a) * p) for a, b in zip(c_top, c_bot))
        d.line([(x0, y0 + i), (x1, y0 + i)], fill=c)


# ---------------- invented worlds ----------------
def world_cloud(mask):
    """Night sky, moon, stars; subject sleeps on a fluffy cloud."""
    r = random.Random(7)
    ys, xs = np.where(mask)
    bx0, bx1, by0, by1 = xs.min(), xs.max(), ys.min(), ys.max()
    bg = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(bg, "RGBA")
    vgrad(d, 0, 0, W, H, (18, 24, 64), (122, 100, 160))
    for _ in range(420):                                   # stars
        x, y = r.random() * W, r.random() * H * 0.75
        s = 1 if r.random() < 0.85 else 2
        d.ellipse([x, y, x + s, y + s], fill=(255, 255, 245, int(120 + r.random() * 135)))
    mx, my, mr = W * 0.82, H * 0.18, W * 0.052              # moon + halo
    for hr in range(int(W * 0.13), 0, -8):
        d.ellipse([mx - hr, my - hr, mx + hr, my + hr],
                  fill=(255, 244, 200, int(3 + (W * 0.13 - hr) * 0.16)))
    d.ellipse([mx - mr, my - mr, mx + mr, my + mr], fill=(252, 244, 214))
    for (ox, oy, cr) in [(-mr * .3, -mr * .17, mr * .2), (mr * .26, mr * .13, mr * .15),
                         (-mr * .07, mr * .35, mr * .11)]:
        d.ellipse([mx + ox - cr, my + oy - cr, mx + ox + cr, my + oy + cr], fill=(228, 216, 182))
    sx, sy = W * 0.14, H * 0.12                             # shooting star
    for i in range(40):
        d.line([sx + i * 5, sy + i * 2.2, sx + i * 5 + 5, sy + i * 2.2 + 2.2],
               fill=(220, 240, 255, int(200 * (1 - i / 40))), width=2)
    for _ in range(5):                                      # distant clouds
        cx, cy = r.random() * W, H * (0.25 + r.random() * 0.3)
        for _ in range(9):
            ex, ey = cx + (r.random() - .5) * 150, cy + (r.random() - .5) * 22
            rw, rh = 26 + r.random() * 36, 8 + r.random() * 9
            d.ellipse([ex - rw, ey - rh, ex + rw, ey + rh], fill=(190, 180, 220, 60))
    ctop = by1 - (by1 - by0) * 0.18                         # THE cloud under the subject
    ccx = (bx0 + bx1) / 2
    cw = (bx1 - bx0) * 0.75 + 140
    for (col, a, dy) in [((150, 140, 190), 160, 46), ((205, 198, 232), 200, 24),
                         ((245, 242, 252), 255, 0)]:
        for _ in range(120):
            ex = ccx + (r.random() - .5) * 2 * cw
            f = 1 - abs(ex - ccx) / (cw * 1.15)
            if f <= 0:
                continue
            ey = ctop + dy + (r.random() - .4) * 46 * f + (1 - f) * 40
            rw = (30 + r.random() * 55) * (.5 + f)
            d.ellipse([ex - rw, ey - rw * .5, ex + rw, ey + rw * .5], fill=col + (a,))
    return bg


def world_meadow(mask):
    """Sunny flower meadow; grass gets painted over the subject's bottom edge."""
    r = random.Random(21)
    bg = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(bg, "RGBA")
    horizon = int(H * 0.42)
    vgrad(d, 0, 0, W, horizon, (110, 190, 235), (215, 240, 225))
    sx, sy = W * 0.15, H * 0.12                             # sun
    for hr in range(130, 0, -8):
        d.ellipse([sx - hr, sy - hr, sx + hr, sy + hr],
                  fill=(255, 250, 200, int(4 + (130 - hr) * 0.2)))
    d.ellipse([sx - 40, sy - 40, sx + 40, sy + 40], fill=(255, 246, 200))
    for _ in range(4):                                      # clouds
        cx, cy = r.random() * W, H * (0.06 + r.random() * 0.2)
        for _ in range(10):
            ex, ey = cx + (r.random() - .5) * 170, cy + (r.random() - .5) * 26
            rw, rh = 30 + r.random() * 40, 10 + r.random() * 10
            d.ellipse([ex - rw, ey - rh, ex + rw, ey + rh], fill=(255, 255, 255, 120))
    # base green FIRST so no bare canvas can peek through (learned this the hard way)
    d.rectangle([0, horizon - 4, W, H], fill=(118, 172, 74))
    for base, amp, c in [(horizon + 30, 40, (128, 176, 96)),   # hills
                         (horizon + 70, 30, (100, 152, 76))]:
        pts = [(0, H)]
        ph = r.random() * 7
        for x in range(0, W + 1, 12):
            pts.append((x, base - (np.sin(x * 0.008 + ph) * .5 + .5) * amp))
        pts.append((W, H))
        d.polygon(pts, fill=c)
    vgrad(d, 0, horizon + 60, W, H, (118, 172, 74), (58, 104, 40))
    for _ in range(5200):                                   # grass blades
        gy = horizon + 70 + (r.random() ** 0.8) * (H - horizon - 70)
        gx = r.random() * W
        dep = (gy - horizon) / (H - horizon)
        sh = r.random()
        c = (86, 140, 58) if sh < .4 else ((140, 190, 90) if sh < .7 else (48, 88, 34))
        d.line([gx, gy, gx + (r.random() - .5) * 12, gy - (5 + dep * 26)],
               fill=c + (200,), width=1 + int(dep * 2.2))
    pal = [(232, 74, 95), (255, 154, 60), (255, 123, 172),
           (245, 240, 230), (178, 107, 255), (255, 210, 63)]
    for _ in range(140):                                    # flowers
        fy = horizon + 80 + (r.random() ** 0.8) * (H - horizon - 90)
        fx = r.random() * W
        fr = 2 + ((fy - horizon) / (H - horizon)) * 7
        col = pal[int(r.random() * len(pal))]
        for p in range(5):
            ang = p / 5 * 2 * np.pi + r.random() * .5
            px, py = fx + np.cos(ang) * fr, fy + np.sin(ang) * fr
            d.ellipse([px - fr * .7, py - fr * .7, px + fr * .7, py + fr * .7], fill=col + (235,))
        d.ellipse([fx - fr * .45, fy - fr * .45, fx + fr * .45, fy + fr * .45],
                  fill=(255, 210, 63, 255) if col != (255, 210, 63) else (138, 90, 26, 255))
    return bg


def composite(bg, mask, soft, mode):
    """Photo subject over the new world + tuck fluff/grass over its bottom edge."""
    out = np.asarray(bg, dtype=np.float32) * (1 - soft) + pa * soft
    comp = Image.fromarray(out.astype(np.uint8))
    d = ImageDraw.Draw(comp, "RGBA")
    r = random.Random(99)
    ys, xs = np.where(mask)
    bx0, bx1 = xs.min(), xs.max()
    for x in range(bx0, bx1, 6):
        col = np.where(mask[:, x])[0]
        if len(col) == 0:
            continue
        yb = col.max()
        if mode == "cloud":
            for _ in range(2):
                ex, ey = x + (r.random() - .5) * 14, yb + (r.random() - .2) * 10
                rw = 9 + r.random() * 16
                d.ellipse([ex - rw, ey - rw * .5, ex + rw, ey + rw * .5],
                          fill=(244, 241, 252, 210))
        elif mode == "meadow":
            for _ in range(3):
                gx2, gy2 = x + (r.random() - .5) * 16, yb + 4 + r.random() * 8
                c = (86, 140, 58) if r.random() < .5 else (52, 92, 36)
                d.line([gx2, gy2, gx2 + (r.random() - .5) * 14, gy2 - (14 + r.random() * 16)],
                       fill=c + (230,), width=2)
    return comp


# ---------------- THE PAINTER ----------------
def painterly(image, layers, out_path):
    """Hertzmann-style stroke painting: strokes ride ALONG edges, big brush to small."""
    tw, th = image.size
    blur = 0.6 if MODE in ("fine", "ultrafine") else 1.2
    ref = np.asarray(image.filter(ImageFilter.GaussianBlur(blur)), dtype=np.float32)
    tgt = np.asarray(image, dtype=np.float32)
    lum = np.asarray(image.convert("L").filter(ImageFilter.GaussianBlur(1.6)), dtype=np.float32)
    gy, gx = np.gradient(lum)
    gmag = np.hypot(gx, gy)

    def tcol(x, y): return ref[min(max(int(y), 0), th - 1), min(max(int(x), 0), tw - 1)]
    def tcs(x, y): return tgt[min(max(int(y), 0), th - 1), min(max(int(x), 0), tw - 1)]
    def cd(a, b): return abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2])

    canvas = Image.new("RGB", (tw, th), (239, 230, 212))    # primed linen
    draw = ImageDraw.Draw(canvas)
    total = 0
    for (R, thresh) in layers:
        snap = np.asarray(canvas, dtype=np.float32) if thresh >= 0 else None
        step = max(R, 2)
        cells = [(x, y) for y in range(step // 2, th, step) for x in range(step // 2, tw, step)]
        random.shuffle(cells)
        n_layer = 0
        for (cx, cy) in cells:
            x = min(max(cx + (random.random() - .5) * step, 0), tw - 1)
            y = min(max(cy + (random.random() - .5) * step, 0), th - 1)
            # only repaint where the canvas is still wrong (like a squinting painter)
            if snap is not None and cd(snap[int(y), int(x)], tcs(x, y)) < thresh:
                continue
            col = tcol(x, y)
            pts = [(x, y)]
            px, py, ldx, ldy = x, y, 0.0, 0.0
            stay = 55 if R <= 2 else (80 if R <= 4 else 110)
            for _ in range(4 + random.randint(0, 8)):
                xi, yi = min(max(int(px), 0), tw - 1), min(max(int(py), 0), th - 1)
                m = gmag[yi, xi]
                if m < 0.6:                                  # flat area: keep going
                    if ldx == 0 and ldy == 0:
                        a = random.random() * 2 * np.pi
                        dx, dy = np.cos(a), np.sin(a)
                    else:
                        dx, dy = ldx, ldy
                else:                                        # ride along the edge
                    dx, dy = -gy[yi, xi] / m, gx[yi, xi] / m
                    if dx * ldx + dy * ldy < 0:
                        dx, dy = -dx, -dy
                    dx = 0.65 * dx + 0.35 * ldx
                    dy = 0.65 * dy + 0.35 * ldy
                    n = np.hypot(dx, dy) or 1.0
                    dx, dy = dx / n, dy / n
                px += dx * R
                py += dy * R
                if not (0 <= px < tw and 0 <= py < th):
                    break
                if cd(tcol(px, py), col) > stay:            # stroke stays in its color
                    break
                pts.append((px, py))
                ldx, ldy = dx, dy
            j = 5 if R <= 2 else 14                          # paint-mixing jitter
            c = tuple(int(min(255, max(0, v + (random.random() - .5) * j))) for v in col)
            wdt = max(1, int(R * 2 * (0.75 + random.random() * .5)))
            if len(pts) == 1:
                rr = wdt / 2
                draw.ellipse([x - rr, y - rr, x + rr, y + rr], fill=c)
            else:
                draw.line(pts, fill=c, width=wdt, joint="curve")
                rr = wdt / 2
                for (ex, ey) in (pts[0], pts[-1]):           # round brush caps
                    draw.ellipse([ex - rr, ey - rr, ex + rr, ey + rr], fill=c)
                if R >= 8 and len(pts) > 2:                  # one bristle highlight
                    hc = tuple(min(255, v + 20) for v in c)
                    ox, oy = (random.random() - .5) * R, (random.random() - .5) * R
                    draw.line([(a + ox, b + oy) for (a, b) in pts], fill=hc,
                              width=max(1, int(R * .5)), joint="curve")
            n_layer += 1
        total += n_layer
        print(f"  brush R={R}: {n_layer} strokes")
    canvas.save(out_path, quality=95)
    print(f"  TOTAL: {total} strokes -> {out_path}")


# ---------------- MARKER mode: comic style ----------------
def marker_paint(image, out_path):
    """Comic style: flat quantized colors, long marker sweeps, bold ink outlines, panel frame."""
    tw, th = image.size
    q = image.filter(ImageFilter.GaussianBlur(1.6))
    if MARKER_VIBRANCE != 1.0:
        # vibrance: boost muted colors a lot, already-strong colors barely
        hsv = np.asarray(q.convert("HSV"), dtype=np.float32)
        s = hsv[:, :, 1]
        hsv[:, :, 1] = np.clip(s * (1 + (MARKER_VIBRANCE - 1) * (1 - s / 255)), 0, 255)
        q = Image.fromarray(hsv.astype(np.uint8), "HSV").convert("RGB")
    q = ImageEnhance.Color(q).enhance(MARKER_SAT)
    q = q.quantize(colors=MARKER_COLORS, method=Image.MEDIANCUT).convert("RGB")
    ref = np.asarray(q, dtype=np.float32)
    lum = np.asarray(q.convert("L").filter(ImageFilter.GaussianBlur(0.8)), dtype=np.float32)
    gy, gx = np.gradient(lum)
    gmag = np.hypot(gx, gy)

    def tcol(x, y): return ref[min(max(int(y), 0), th - 1), min(max(int(x), 0), tw - 1)]
    def cd(a, b): return abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2])

    canvas = Image.new("RGB", (tw, th), (250, 248, 242))
    draw = ImageDraw.Draw(canvas, "RGBA")
    total = 0
    base_angle = -0.55 + random.random() * 0.3            # the artist's hatch angle
    # marker fills: long sweeps, big to small
    for (R, thresh) in [(13, -1), (6, 45), (3, 50)]:
        snap = np.asarray(canvas, dtype=np.float32) if thresh >= 0 else None
        step = max(R, 2)
        cells = [(x, y) for y in range(step // 2, th, step) for x in range(step // 2, tw, step)]
        random.shuffle(cells)
        n_layer = 0
        for (cx, cy) in cells:
            x = min(max(cx + (random.random() - .5) * step, 0), tw - 1)
            y = min(max(cy + (random.random() - .5) * step, 0), th - 1)
            if snap is not None and cd(snap[int(y), int(x)], tcol(x, y)) < thresh:
                continue
            col = tcol(x, y)
            pts = [(x, y)]
            px, py, ldx, ldy = x, y, 0.0, 0.0
            for _ in range(10 + random.randint(0, 18)):    # LONG marker sweeps
                xi, yi = min(max(int(px), 0), tw - 1), min(max(int(py), 0), th - 1)
                m = gmag[yi, xi]
                if m < 0.6:                                # flat region: sweep along hatch angle
                    if ldx == 0 and ldy == 0:
                        a = base_angle + (random.random() - .5) * 0.25
                        dx, dy = np.cos(a), np.sin(a)
                    else:
                        dx, dy = ldx, ldy
                else:                                      # near an edge: follow it
                    dx, dy = -gy[yi, xi] / m, gx[yi, xi] / m
                    if dx * ldx + dy * ldy < 0:
                        dx, dy = -dx, -dy
                    dx = 0.7 * dx + 0.3 * ldx
                    dy = 0.7 * dy + 0.3 * ldy
                    n = np.hypot(dx, dy) or 1.0
                    dx, dy = dx / n, dy / n
                px += dx * R
                py += dy * R
                if not (0 <= px < tw and 0 <= py < th):
                    break
                if cd(tcol(px, py), col) > 40:             # markers never cross a color line
                    break
                pts.append((px, py))
                ldx, ldy = dx, dy
            c = tuple(int(v) for v in col)
            alpha = 190 if MARKER_STREAKS else 255
            wdt = max(2, int(R * 2))
            if len(pts) == 1:
                rr = wdt / 2
                draw.ellipse([x - rr, y - rr, x + rr, y + rr], fill=c + (alpha,))
            else:
                draw.line(pts, fill=c + (alpha,), width=wdt, joint="curve")
                rr = wdt / 2
                for (ex, ey) in (pts[0], pts[-1]):
                    draw.ellipse([ex - rr, ey - rr, ex + rr, ey + rr], fill=c + (alpha,))
                if MARKER_STREAKS:
                    lite = tuple(min(255, v + 18) for v in c)  # streaky marker core
                    draw.line(pts, fill=lite + (110,), width=max(1, int(wdt * 0.45)), joint="curve")
            n_layer += 1
        total += n_layer
        print(f"  marker R={R}: {n_layer} strokes")
    # ink: bold lines along edges; ink follows its OWN wider-blurred gradient field
    lum2 = np.asarray(q.convert("L").filter(ImageFilter.GaussianBlur(2.4)), dtype=np.float32)
    gy2, gx2 = np.gradient(lum2)
    gmag2 = np.hypot(gx2, gy2)
    ink = (28, 24, 34, 255)
    n_ink = 0
    cells = [(x, y) for y in range(2, th, 3) for x in range(2, tw, 3)]
    random.shuffle(cells)
    inked = np.zeros((th, tw), dtype=bool)
    for (x, y) in cells:
        if gmag2[y, x] < 20 or inked[y, x]:
            continue
        pts = [(float(x), float(y))]
        px, py, ldx, ldy = float(x), float(y), 0.0, 0.0
        for _ in range(36):
            xi, yi = min(max(int(px), 0), tw - 1), min(max(int(py), 0), th - 1)
            m = gmag2[yi, xi]
            if m < 9:
                break
            dx, dy = -gy2[yi, xi] / m, gx2[yi, xi] / m
            if dx * ldx + dy * ldy < 0:
                dx, dy = -dx, -dy
            dx = 0.75 * dx + 0.25 * ldx
            dy = 0.75 * dy + 0.25 * ldy
            n = np.hypot(dx, dy) or 1.0
            dx, dy = dx / n, dy / n
            px += dx * 2.4
            py += dy * 2.4
            if not (0 <= px < tw and 0 <= py < th):
                break
            pts.append((px, py))
            ldx, ldy = dx, dy
            iy, ix = int(py), int(px)
            inked[max(0, iy - 2):iy + 3, max(0, ix - 2):ix + 3] = True
        if len(pts) < 3:
            continue
        wdt = 3 + int(random.random() * 3)                 # pen weight varies
        draw.line(pts, fill=ink, width=wdt, joint="curve")
        rr = wdt / 2
        for (ex, ey) in (pts[0], pts[-1]):
            draw.ellipse([ex - rr, ey - rr, ex + rr, ey + rr], fill=ink)
        n_ink += 1
    total += n_ink
    print(f"  ink lines: {n_ink} strokes")
    # comic panel frame
    m = int(tw * 0.02)
    draw.rectangle([0, 0, tw, m], fill=(250, 248, 242, 255))
    draw.rectangle([0, th - m, tw, th], fill=(250, 248, 242, 255))
    draw.rectangle([0, 0, m, th], fill=(250, 248, 242, 255))
    draw.rectangle([tw - m, 0, tw, th], fill=(250, 248, 242, 255))
    draw.rectangle([m, m, tw - m, th - m], outline=(28, 24, 34, 255), width=int(m * 0.6))
    canvas.save(out_path, quality=95)
    print(f"  TOTAL: {total} strokes -> {out_path}")


# ---------------- REALISTIC BRUSHES painter ----------------
def painterly_realistic(image, layers, out_path):
    """Like painterly(), but strokes behave like real loaded brushes:
    taper (land thin, press fat, lift thin), bristle streaks, impasto
    light/shadow relief, dry-brush ends on long strokes, canvas weave."""
    tw, th = image.size
    ref = np.asarray(image.filter(ImageFilter.GaussianBlur(0.8)), dtype=np.float32)
    tgt2 = np.asarray(image, dtype=np.float32)
    lum2 = np.asarray(image.convert("L").filter(ImageFilter.GaussianBlur(1.8)), dtype=np.float32)
    gyy, gxx = np.gradient(lum2)
    gmm = np.hypot(gxx, gyy)

    def tcol(x, y): return ref[min(max(int(y), 0), th - 1), min(max(int(x), 0), tw - 1)]
    def tcs(x, y): return tgt2[min(max(int(y), 0), th - 1), min(max(int(x), 0), tw - 1)]
    def cd(a, b): return abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2])

    # canvas with linen weave
    yy, xx = np.mgrid[0:th, 0:tw].astype(np.float32)
    weave = 4.5 * (np.sin(xx * np.pi / 3.1) + np.sin(yy * np.pi / 3.1)) \
          + 3.0 * np.random.default_rng(SEED).standard_normal((th, tw))
    cb = np.stack([238 + weave, 229 + weave, 211 + weave], axis=2)
    canvas = Image.fromarray(np.clip(cb, 0, 255).astype(np.uint8))
    draw = ImageDraw.Draw(canvas, "RGBA")

    def make_stroke(x0, y0, R):
        col = tcol(x0, y0)
        pts = [(x0, y0)]
        x, y, ldx, ldy = x0, y0, 0.0, 0.0
        stay = 70 if R <= 3 else 105
        for _ in range(5 + random.randint(0, 9)):
            xi, yi = min(max(int(x), 0), tw - 1), min(max(int(y), 0), th - 1)
            m = gmm[yi, xi]
            if m < 0.6:
                if ldx == 0 and ldy == 0:
                    a = random.random() * 2 * np.pi
                    dx, dy = np.cos(a), np.sin(a)
                else:
                    dx, dy = ldx, ldy
            else:
                dx, dy = -gyy[yi, xi] / m, gxx[yi, xi] / m
                if dx * ldx + dy * ldy < 0:
                    dx, dy = -dx, -dy
                dx = 0.65 * dx + 0.35 * ldx
                dy = 0.65 * dy + 0.35 * ldy
                n = np.hypot(dx, dy) or 1.0
                dx, dy = dx / n, dy / n
            x += dx * R
            y += dy * R
            if not (0 <= x < tw and 0 <= y < th):
                break
            if cd(tcol(x, y), col) > stay:
                break
            pts.append((x, y))
            ldx, ldy = dx, dy
        return pts, col

    def render(pts, col, R):
        fine = []
        for i in range(len(pts) - 1):
            x0, y0 = pts[i]; x1, y1 = pts[i + 1]
            seg = max(1, int(np.hypot(x1 - x0, y1 - y0) / max(1.5, R * 0.5)))
            for k in range(seg):
                t = k / seg
                fine.append((x0 + (x1 - x0) * t, y0 + (y1 - y0) * t))
        fine.append(pts[-1])
        n = len(fine)
        j = 6 if R <= 3 else 13
        base = tuple(int(min(255, max(0, v + (random.random() - .5) * j))) for v in col)
        if n < 2:
            r = max(1, R * 0.7)
            draw.ellipse([pts[0][0] - r, pts[0][1] - r, pts[0][0] + r, pts[0][1] + r], fill=base)
            return
        ts = np.linspace(0, 1, n)
        widths = [max(1.0, R * (0.35 + 0.85 * np.sin(np.pi * t) ** 0.6)
                      * (1 + (random.random() - .5) * 0.22)) for t in ts]
        perps = []
        for i in range(n):
            a, b = fine[max(0, i - 1)], fine[min(n - 1, i + 1)]
            dx, dy = b[0] - a[0], b[1] - a[1]
            L = np.hypot(dx, dy) or 1.0
            perps.append((-dy / L, dx / L))
        dry = len(pts) >= 6
        shadow = tuple(int(v * 0.76) for v in base)
        hi = tuple(min(255, int(v * 1.16 + 16)) for v in base)
        off = 1.0 + R * 0.11
        if R >= 5:
            for i in range(n - 1):
                draw.line([fine[i][0] + off, fine[i][1] + off,
                           fine[i + 1][0] + off, fine[i + 1][1] + off],
                          fill=shadow + (95,), width=int(widths[i] * 2))
        for i in range(n - 1):
            if dry and ts[i] > 0.8 and random.random() < 0.38:
                continue
            pick = 0.22 * ts[i]
            loc = tcol(*fine[i])
            c = tuple(int(base[k] * (1 - pick) + loc[k] * pick) for k in range(3))
            w = max(1, int(widths[i] * 2))
            draw.line([fine[i][0], fine[i][1], fine[i + 1][0], fine[i + 1][1]], fill=c, width=w)
            r = w / 2
            draw.ellipse([fine[i][0] - r, fine[i][1] - r, fine[i][0] + r, fine[i][1] + r], fill=c)
        r = max(1, widths[-1])
        draw.ellipse([fine[-1][0] - r, fine[-1][1] - r, fine[-1][0] + r, fine[-1][1] + r], fill=base)
        if R >= 5:
            for o, dk in [(-0.45, 0.88), (0.1, 1.06), (0.42, 0.92)]:
                bc = tuple(int(min(255, v * dk)) for v in base)
                bpts = [(fine[i][0] + perps[i][0] * o * widths[i],
                         fine[i][1] + perps[i][1] * o * widths[i]) for i in range(n)]
                draw.line(bpts, fill=bc + (115,), width=max(1, int(R * 0.28)), joint="curve")
            m2 = max(2, int(n * 0.75))
            hpts = [(fine[i][0] - off * 0.7 + perps[i][0] * (-0.25) * widths[i],
                     fine[i][1] - off * 0.7 + perps[i][1] * (-0.25) * widths[i])
                    for i in range(m2)]
            draw.line(hpts, fill=hi + (135,), width=max(1, int(R * 0.3)), joint="curve")

    total = 0
    for (R, thresh) in layers:
        snap = np.asarray(canvas, dtype=np.float32) if thresh >= 0 else None
        step = max(R, 2)
        cells = [(x, y) for y in range(step // 2, th, step) for x in range(step // 2, tw, step)]
        random.shuffle(cells)
        n_layer = 0
        for (cx, cy) in cells:
            x = min(max(cx + (random.random() - .5) * step, 0), tw - 1)
            y = min(max(cy + (random.random() - .5) * step, 0), th - 1)
            if snap is not None and cd(snap[int(y), int(x)], tcs(x, y)) < thresh:
                continue
            pts, col = make_stroke(x, y, R)
            render(pts, col, R)
            n_layer += 1
        total += n_layer
        print(f"  brush R={R}: {n_layer} strokes")
    canvas.save(out_path, quality=95)
    print(f"  TOTAL: {total} strokes -> {out_path}")


# ---------------- run ----------------
if WORLD == "none":
    source = photo
else:
    mask, soft = dark_subject_mask()
    bg = world_cloud(mask) if WORLD == "cloud" else world_meadow(mask)
    source = composite(bg, mask, soft, WORLD)

print(f"painting: mode={MODE}, world={WORLD}, canvas={source.size}")
if MODE == "marker":
    marker_paint(source, OUT)
elif REALISTIC_BRUSHES:
    painterly_realistic(source, MODE_LAYERS[MODE], OUT)
else:
    painterly(source, MODE_LAYERS[MODE], OUT)
print("done")
