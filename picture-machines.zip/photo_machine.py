#!/usr/bin/env python3
"""
THE PHOTO MACHINE — one command that runs all the picture machines.
by Peter + Claude, 2026.

  python3 photo_machine.py cat.jpg --all
  python3 photo_machine.py cat.jpg --comic press --paint fine
  python3 photo_machine.py logo.png --litho hex
  python3 photo_machine.py cat.jpg --litho card --set WIDTH_MM=140 MAX_MM=3.4

Machines:
  paint  = brush-stroke painting          (paint_anything.py)
  comic  = printed comic / CMYK press     (comicify.py)
  litho  = 3D-printable lithophane STL    (lithophane.py)
"""
import argparse, os, re, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable

MACHINES = {
    "paint": dict(script="paint_anything.py", key="MODE",
                  presets={p: {} for p in ("chunky", "normal", "fine", "ultrafine", "marker")},
                  default="fine", ext="png"),
    "comic": dict(script="comicify.py", key="STYLE",
                  presets={p: {} for p in ("clean", "retro", "press", "poster", "manga")},
                  default="press", ext="png"),
    "litho": dict(script="lithophane.py", key=None, default="card", ext="stl",
                  presets={
                    # the standard photo plate for a window or a lamp
                    "card":     dict(WIDTH_MM=100.0, SHAPE='"rounded"', MIN_MM=0.7, MAX_MM=3.0, RES=8.0),
                    # the 3D logo shape, with a hole to hang it
                    "hex":      dict(WIDTH_MM=70.0, HEIGHT_MM=70.0, SHAPE='"hex"', HANG_MM=4.0, MAX_MM=2.8),
                    "hex-flat": dict(WIDTH_MM=70.0, HEIGHT_MM=70.0, SHAPE='"hex-flat"', HANG_MM=4.0, MAX_MM=2.8),
                    # round tree ornament / keyring
                    "ornament": dict(WIDTH_MM=60.0, HEIGHT_MM=60.0, SHAPE='"circle"', HANG_MM=4.0, MAX_MM=2.6),
                    # small badge: fast to print, sells cheap
                    "badge":    dict(WIDTH_MM=40.0, SHAPE='"rounded"', CORNER_MM=3.0, MIN_MM=0.6,
                                     MAX_MM=2.2, RES=6.0, HANG_MM=3.0),
                    # bent around a lamp - warps less, looks pro
                    "curved":   dict(WIDTH_MM=100.0, CURVE_R=60.0, SHAPE='"rect"', MAX_MM=3.0),
                    # big framed night-light panel
                    "night":    dict(WIDTH_MM=130.0, SHAPE='"rect"', FRAME_MM=3.0, MAX_MM=3.4),
                    # framed hexagon plaque: the 3D logo shape with a raised rim
                    "plaque":   dict(WIDTH_MM=80.0, HEIGHT_MM=80.0, SHAPE='"hex"', HANG_MM=4.5,
                                     FRAME_MM=4.0, FRAME_THICK_MM=4.5, MAX_MM=2.8),
                  }),
}

def run(machine, preset, photo, outdir, extra):
    spec = MACHINES[machine]
    src = open(os.path.join(HERE, spec["script"])).read()
    base = os.path.splitext(os.path.basename(photo))[0]
    out = os.path.join(outdir, f"{base}-{machine}-{preset}.{spec['ext']}")
    over = {"PHOTO": f'"{photo}"', "OUT": f'"{out}"'}
    if spec["key"]:
        over[spec["key"]] = f'"{preset}"'
    over.update({k: (v if isinstance(v, str) else repr(v))
                 for k, v in spec["presets"].get(preset, {}).items()})
    if machine == "litho":
        over["PREVIEW"] = f'"{os.path.join(outdir, base)}-litho-{preset}-preview.png"'
    over.update(extra)
    for k, v in over.items():
        src, n = re.subn(rf"(?m)^{k}(\s*)=.*?(\s+#.*)?$", lambda m: f"{k}{m.group(1)}= {v}", src, count=1)
        if not n:
            print(f"    ! no setting called {k} in {spec['script']}")
    tmp = os.path.join(outdir, f".run_{machine}_{preset}.py")
    open(tmp, "w").write(src)
    t0 = time.time()
    r = subprocess.run([PY, tmp], capture_output=True, text=True)
    os.remove(tmp)
    ok = r.returncode == 0
    for line in (r.stdout or "").strip().splitlines():
        print("   ", line)
    if not ok:
        print("    FAILED:", (r.stderr or "").strip().splitlines()[-1][:200] if r.stderr else "?")
    return ok, out, time.time() - t0

def main():
    ap = argparse.ArgumentParser(description="run every picture machine on one photo")
    ap.add_argument("photo")
    ap.add_argument("--paint", nargs="?", const="fine")
    ap.add_argument("--comic", nargs="?", const="press")
    ap.add_argument("--litho", nargs="?", const="card")
    ap.add_argument("--all", action="store_true", help="paint:fine + comic:press + litho:card")
    ap.add_argument("--out", default=".", help="output folder")
    ap.add_argument("--set", nargs="*", default=[], metavar="KEY=VALUE",
                    help="override any setting, e.g. --set WIDTH_MM=140 INK=1.4")
    a = ap.parse_args()

    photo = os.path.abspath(a.photo)
    outdir = os.path.abspath(a.out)
    os.makedirs(outdir, exist_ok=True)
    extra = {}
    for kv in a.set:
        k, _, v = kv.partition("=")
        extra[k.strip()] = v.strip()

    jobs = []
    if a.all:
        jobs = [("paint", "fine"), ("comic", "press"), ("litho", "card")]
    else:
        for m in ("paint", "comic", "litho"):
            p = getattr(a, m)
            if p:
                if p not in MACHINES[m]["presets"]:
                    sys.exit(f"unknown {m} preset '{p}'. choose: {', '.join(MACHINES[m]['presets'])}")
                jobs.append((m, p))
    if not jobs:
        sys.exit("pick at least one: --paint / --comic / --litho / --all")

    print(f"PHOTO MACHINE  ->  {os.path.basename(photo)}   ({len(jobs)} job{'s' if len(jobs)>1 else ''})\n")
    done = []
    for m, p in jobs:
        print(f"[{m}:{p}]")
        ok, out, secs = run(m, p, photo, outdir, extra)
        done.append((m, p, ok, out, secs))
        print()
    print("summary")
    for m, p, ok, out, secs in done:
        mark = "ok " if ok else "FAIL"
        size = f"{os.path.getsize(out)/1048576:.1f} MB" if ok and os.path.exists(out) else "-"
        print(f"  {mark} {m}:{p:<9} {secs:5.1f}s  {size:>8}  {os.path.basename(out)}")

if __name__ == "__main__":
    main()
